#include <SFML/Graphics.hpp>
#include <vector>
#include <string>

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Grafica de Maximización");

    // Cargar fuente para números
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        return -1; // Error si no carga
    }

    sf::Vector2f origin(50, 550); // (0,0) en pantalla
    float scale = 50.f;           // 1 unidad = 50 píxeles

    // Transformar coordenadas matemáticas a pantalla
    auto toScreen = [&](float x, float y) {
        return sf::Vector2f(origin.x + x * scale, origin.y - y * scale);
    };

    // Dibujar región factible (polígono)
    std::vector<sf::Vector2f> feasibleRegion = {
        toScreen(0, 0),
        toScreen(0, 10),
        toScreen(4, 10),
        toScreen(7, 0)
    };

    sf::ConvexShape region;
    region.setPointCount(feasibleRegion.size());
    for (size_t i = 0; i < feasibleRegion.size(); ++i) {
        region.setPoint(i, feasibleRegion[i]);
    }
    region.setFillColor(sf::Color(100, 100, 255, 150)); // Azul semitransparente

    // Ejes
    sf::Vertex xAxis[] = {
        sf::Vertex(toScreen(0, 0), sf::Color::White),
        sf::Vertex(toScreen(10, 0), sf::Color::White)
    };
    sf::Vertex yAxis[] = {
        sf::Vertex(toScreen(0, 0), sf::Color::White),
        sf::Vertex(toScreen(0, 12), sf::Color::White)
    };

    // Restricciones
    sf::Vertex line1[] = {
        toScreen(0, 10), toScreen(10, 0) // x + y = 10
    };
    sf::Vertex line2[] = {
        toScreen(0, 14), toScreen(7, 0)  // 2x + y = 14
    };

    // Crear números para ejes
    std::vector<sf::Text> labels;

    // Eje X
    for (int i = 0; i <= 10; ++i) {
        sf::Text label(std::to_string(i), font, 14);
        label.setFillColor(sf::Color::White);
        label.setPosition(toScreen(i, 0).x - 5, toScreen(i, 0).y + 5);
        labels.push_back(label);
    }

    // Eje Y
    for (int i = 0; i <= 12; ++i) {
        sf::Text label(std::to_string(i), font, 14);
        label.setFillColor(sf::Color::White);
        label.setPosition(toScreen(0, i).x - 25, toScreen(0, i).y - 7);
        labels.push_back(label);
    }

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear(sf::Color::Black);

        // Ejes
        window.draw(xAxis, 2, sf::Lines);
        window.draw(yAxis, 2, sf::Lines);

        // Restricciones
        window.draw(line1, 2, sf::Lines);
        window.draw(line2, 2, sf::Lines);

        // Región factible
        window.draw(region);

        // Números en ejes
        for (auto& label : labels)
            window.draw(label);

        window.display();
    }

    return 0;
}
